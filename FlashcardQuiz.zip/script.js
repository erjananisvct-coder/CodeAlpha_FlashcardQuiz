const flashcards = [
  {
    question: "What is HTML?",
    answer: "HTML stands for HyperText Markup Language."
  },
  {
    question: "What is CSS?",
    answer: "CSS stands for Cascading Style Sheets."
  },
  {
    question: "What is JavaScript?",
    answer: "JavaScript is a programming language used to make web pages interactive."
  }
];

let currentCard = 0;

function loadCard() {
  document.getElementById("question").innerText = flashcards[currentCard].question;
  document.getElementById("answer").innerText = flashcards[currentCard].answer;
  document.getElementById("answer").style.display = "none";
}

function showAnswer() {
  document.getElementById("answer").style.display = "block";
}

function nextCard() {
  currentCard++;
  if (currentCard >= flashcards.length) {
    currentCard = 0;
  }
  loadCard();
}

function previousCard() {
  currentCard--;
  if (currentCard < 0) {
    currentCard = flashcards.length - 1;
  }
  loadCard();
}

loadCard();